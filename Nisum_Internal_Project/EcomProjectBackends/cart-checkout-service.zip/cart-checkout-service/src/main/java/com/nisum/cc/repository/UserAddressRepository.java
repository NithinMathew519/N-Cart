package com.nisum.cc.repository;

import com.nisum.cc.entity.UserAddress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserAddressRepository extends JpaRepository<UserAddress,Long> {
    public List<UserAddress> findByEmail(String email);
}
