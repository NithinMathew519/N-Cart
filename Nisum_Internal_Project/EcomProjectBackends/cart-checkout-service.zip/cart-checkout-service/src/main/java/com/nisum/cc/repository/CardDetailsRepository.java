package com.nisum.cc.repository;

import com.nisum.cc.entity.CardDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CardDetailsRepository extends JpaRepository<CardDetails, Integer> {
}
