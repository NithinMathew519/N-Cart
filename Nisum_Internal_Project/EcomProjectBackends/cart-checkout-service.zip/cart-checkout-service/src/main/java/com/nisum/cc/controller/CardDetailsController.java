package com.nisum.cc.controller;

import com.nisum.cc.entity.CardDetails;
import com.nisum.cc.entity.UserCreditCard;
import com.nisum.cc.repository.CardDetailsRepository;
import com.nisum.cc.service.CardDetailsService;
import com.nisum.cc.service.UserCreditCardService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;


import java.util.List;
@RestController
@RequestMapping("/card")
@CrossOrigin(originPatterns = "http://localhost:4200/")
public class CardDetailsController {
    @Autowired
    private CardDetailsService cardDetailsService;

    @Autowired
    private UserCreditCardService userCreditCardService;

    @Autowired
    private CardDetailsRepository cardDetailsRepository;

    @GetMapping
    public List<CardDetails> findAllCardDetails() {
        return cardDetailsService.getCardDetails();
    }

    @GetMapping("/user/{email}")
    public List<UserCreditCard> getAllUserCreditCard(@PathVariable String email) {
        System.out.println(email);
        return userCreditCardService.getAllCreditCardByEmail(email);
    }
    @PostMapping("/addcard")
    public CardDetails addCardDetails(@RequestBody CardDetails cardDetails) {
        return cardDetailsService.saveCardDetails(cardDetails);
    }

}
