package com.nisum.cc.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.nisum.cc.entity.Order;

public interface OrderRepository extends JpaRepository<Order,Integer>{
    
	public Optional<Order> findByOrderId(Integer orderId);
}
