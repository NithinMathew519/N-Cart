package com.nisum.cc.service;

import com.nisum.cc.entity.Order;
import com.nisum.cc.entity.OrderDetails;
import com.nisum.cc.repository.OrderDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class OrderDetailsService {
    @Autowired
    OrderDetailsRepository orderDetailsRepository;

//    public void addDetailsToOrder(List<OrderDetails> orderDetails,Order order){
//
//        List<OrderDetails> newOrderDetails = orderDetails.stream()
//                .map(e->{ OrderDetails od =new OrderDetails();
//                    od.setItemId(e.getItemId());
//                    od.setQuantity(e.getQuantity());
//                    od.setOrder(order);
//                        return e;})
//                .collect(Collectors.toList());
//
//        OrderDetails od =new OrderDetails();
//        od.setOrder(order);
//        orderDetailsRepository.save(od);
////        orderDetailsRepository.saveAll(newOrderDetails);
//    }
 public OrderDetails addOrderDetails(OrderDetails orderDetails){

     return  orderDetailsRepository.save(orderDetails);
 }

 public OrderDetails getOrderDetailsById(int orderDetailsId){

     Optional<OrderDetails> r = orderDetailsRepository.findById(orderDetailsId);
     if(r.isPresent()) return r.get();
     return new OrderDetails();
 }

}
