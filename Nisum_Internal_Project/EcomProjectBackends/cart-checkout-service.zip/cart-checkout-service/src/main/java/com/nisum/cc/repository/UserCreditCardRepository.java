package com.nisum.cc.repository;

import com.nisum.cc.entity.UserCreditCard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserCreditCardRepository extends JpaRepository<UserCreditCard,Long> {
    public List<UserCreditCard> findByEmail(String email);
}
