package com.nisum.cc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.nisum.cc.entity.Cart;
import com.nisum.cc.service.CartService;

/**
 * Please see the /cart url class for true identity
 * @author hmuppala
 */
@RequestMapping("/cart")
@CrossOrigin(originPatterns = {"http://localhost:4200","http://localhost:51940"})
@RestController
public class CartController {


    @Autowired
    CartService cartService;

    /**
     * Returns the list of items present in the cart.
     * @param email By email ,we are getting the items of one specific user.
     * @return it will return the cart items.
     */
    //Get All cart items by email
    @GetMapping(value = "/{email}", produces = "application/json")
    public List<Cart> getAllCartItems(@PathVariable String email) {
        if (email == null || email.isEmpty()) {
            throw new RuntimeException("email cannot be null and empty");
        }
        List<Cart> allCartItems = cartService.getAllCartItems(email);
        return allCartItems;
    }

    /**
     * To Add the new item int the cart
     * @param cart By cart object ,to add the item in the cart
     * @return returning the cart .
     */
    @PostMapping("/addcart")
    public Cart addItemToCart(@RequestBody Cart cart) {
        if(cart==null){
            throw new RuntimeException("Cart is null,you cannot add item into the cart");
        }
        return cartService.addItemToCart(cart);
    }

    /**
     * To remove the item present in the cart.
     * @param cartId Based on Cart Id only it will delete the specific cart
     * @return if the cart is deleted will return true response.
     */
    @DeleteMapping("/{cartId}")
    public boolean deleteAllCartById(@PathVariable int cartId) {
        if(cartId==0){

            throw new RuntimeException("CartId Can't be zero");

        }
        return cartService.deleteByCartId(cartId);
    }

    /**
     * If the user wants to increase the quantity of item.
     * then based on cartId (i.e.,items are already present in the cart)
     * only that item should be incremented.
     * @param cartId tells the which cart should be updated.
     * @param quantity using patch mapping it will update the specific field.
     * @return item present in the cart
     */
    @PatchMapping("/{cartId}/{quantity}")
    public Cart updateQuantityOfCart(@PathVariable int cartId, @PathVariable int quantity) {
        return cartService.updateQuantityByCartId(cartId, quantity);
    }

    /**
     * If the cart is empty,delete the items in the cart
     * @param Ids pass the list of cart Id's
     * @return if the all items are deleted will give response true.
     */
    @PostMapping(consumes = "application/json")
    public boolean deleteAllCartItems(@RequestBody List<Integer> Ids) {
        if(Ids.isEmpty())
            throw new RuntimeException("cart items to be deleted");
        return cartService.deleteAllCartItems(Ids);
    }

}
