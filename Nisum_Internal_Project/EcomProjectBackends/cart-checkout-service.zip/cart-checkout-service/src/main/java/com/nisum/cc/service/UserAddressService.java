package com.nisum.cc.service;

import com.nisum.cc.entity.UserAddress;
import com.nisum.cc.repository.UserAddressRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserAddressService {
    @Autowired
    UserAddressRepository userAddressRepository;

    public List<UserAddress> findAllAddress(){
        return userAddressRepository.findAll();
    }
    public List<UserAddress> findByAddressByEmail(String email){
        return userAddressRepository.findByEmail(email);
    }
}
