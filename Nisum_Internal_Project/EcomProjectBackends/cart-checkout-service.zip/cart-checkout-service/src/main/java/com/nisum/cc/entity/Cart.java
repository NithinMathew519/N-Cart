package com.nisum.cc.entity;

import lombok.*;

import javax.persistence.*;

@Entity

@Getter
@Setter
@Table(name="cart")
public class Cart {
	
    @OneToOne
	@JoinColumn(name="item_id",nullable=false,referencedColumnName = "item_id")
	private Item item;
    
	@Id
	@Column(name="c_id")
	@SequenceGenerator(
			name="cart_sequence",
			sequenceName="cart_sequence",allocationSize = 1,
			initialValue = 101)
	@GeneratedValue(
			strategy =GenerationType.SEQUENCE,
			generator = "cart_sequence"
	)
	private int cartId;
	
	@Column(name="email")
	private String email;

	@Column(name="quantity")
	private int quantity;

	public Cart(Item item, int cartId, String email, int quantity) {
		this.item = item;
		this.cartId = cartId;
		this.email = email;
		this.quantity = quantity;
	}
	public Cart(){}
	public Item getItem() {
		return item;
	}

	public void setItem(Item item) {
		this.item = item;
	}

	public int getCartId() {
		return cartId;
	}

	public void setCartId(int cartId) {
		this.cartId = cartId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
}
