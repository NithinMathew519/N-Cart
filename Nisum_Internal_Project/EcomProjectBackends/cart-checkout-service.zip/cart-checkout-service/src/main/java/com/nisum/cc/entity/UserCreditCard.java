package com.nisum.cc.entity;

import javax.persistence.*;
@Entity
@Table(name = "user_creditcard")
public class UserCreditCard {
    @Id
    @Column(name = "user_creditcard_id")
    private long userCreditCardId;
    @Column(name = "email")
    private String email;
    @OneToOne
    @JoinColumn(name = "c_id", referencedColumnName = "c_id")
    private CardDetails card;

    public UserCreditCard() {
    }

    public UserCreditCard(int userCreditCardId, String email, CardDetails card) {
        this.userCreditCardId = userCreditCardId;
        this.email = email;
        this.card = card;
    }

    public long getUserCreditCardId() {
        return userCreditCardId;
    }

    public void setUserCreditCardId(int userCreditCardId) {
        this.userCreditCardId = userCreditCardId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public CardDetails getCard() {
        return card;
    }

    public void setCard(CardDetails card) {
        this.card = card;
    }
}
