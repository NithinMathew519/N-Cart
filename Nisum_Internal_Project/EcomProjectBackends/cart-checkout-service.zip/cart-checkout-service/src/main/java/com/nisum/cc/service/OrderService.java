package com.nisum.cc.service;

import com.nisum.cc.entity.Order;
import com.nisum.cc.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * OrderService contains service methods for Placing an Order and get Order By Id.
 *
 * @author Harish, Harshitha
 */
@Service
public class
OrderService {

    @Autowired
    OrderRepository orderRepository;

    /**
     * Method to find an oder by order id, if present it will return order or else Throw an
     * RuntimeException.
     *
     * @param orderId
     * @return Order
     * @throws RuntimeException
     */
    public Order findByOrderId(int orderId) {
        Optional<Order> r = orderRepository.findByOrderId(orderId);
        if (r.isPresent()) return r.get();
        throw new RuntimeException("Order with given Order Id " + orderId + " not found.");
    }

    /**
     * Method to save an oder into table, if duplicate order present with same order id
     * it will throw RuntimeException.
     *
     * @param order
     * @return Order
     * @throws RuntimeException
     */
    public Order saveOrder(Order order) {
        if (orderRepository.existsById(order.getOrderId()))

            throw new RuntimeException("Order with Order Id " + order.getOrderId() + " is already exist.");
        return orderRepository.save(order);

    }


}
