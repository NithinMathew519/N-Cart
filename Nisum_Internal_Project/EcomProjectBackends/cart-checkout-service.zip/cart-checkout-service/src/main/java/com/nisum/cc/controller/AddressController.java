package com.nisum.cc.controller;
import com.nisum.cc.entity.Address;
import com.nisum.cc.entity.UserAddress;
import com.nisum.cc.repository.AddressRepository;
import com.nisum.cc.repository.UserAddressRepository;
import com.nisum.cc.service.AddressService;
import com.nisum.cc.service.UserAddressService;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Post request to add address while in checkout
 * @author schowdhury
 */
@RestController
@RequestMapping("/api/v1")
@CrossOrigin(originPatterns = {"http://localhost:4200"})
public class AddressController {
    @Autowired
    AddressService addressService;
    @Autowired
    UserAddressService userAddressService;
    @Autowired
    AddressRepository addressRepository;

    /**
     *
     * @param address
     * @return address
     */
    @PostMapping(consumes = "application/json")
    public Address addAddress(@RequestBody Address address){

        return addressService.insertAddress(address);
    }

}
