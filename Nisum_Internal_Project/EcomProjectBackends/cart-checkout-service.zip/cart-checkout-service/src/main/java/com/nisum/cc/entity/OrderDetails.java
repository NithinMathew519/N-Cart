package com.nisum.cc.entity;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonBackReference;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="orderdetails")
public class OrderDetails {

	  
	  @Id
	  @SequenceGenerator(
			  name="order_details_sequence",
			  sequenceName="order_details_sequence",allocationSize = 1,
			  initialValue = 1)
	  @GeneratedValue(
			  strategy =GenerationType.SEQUENCE,
			  generator = "order_details_sequence"
	  )
	  @Column(name="order_details_id")
	  private int orderDetailsId;
    	  

	  
	  @Column(name="quantity")
      private int quantity;

	@Column(name="item_id")
	private int itemId;


	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public OrderDetails(int orderDetailsId, int quantity, int itemId) {
		this.orderDetailsId = orderDetailsId;
		this.quantity = quantity;
		this.itemId = itemId;
	}

	public int getOrderDetailsId() {
		return orderDetailsId;
	}

	public void setOrderDetailsId(int orderDetailsId) {
		this.orderDetailsId = orderDetailsId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
}
