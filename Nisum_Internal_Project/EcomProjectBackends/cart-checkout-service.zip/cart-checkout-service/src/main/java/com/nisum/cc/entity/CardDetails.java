package com.nisum.cc.entity;

import lombok.*;

import javax.persistence.*;
import java.math.BigInteger;

/**
 *
 *
 * @author Lokesh Singh
 */
@Entity
@Table(
        name = "credit_cards"
)
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class CardDetails {
    @Id
    @SequenceGenerator(
            name = "cards_sequence",
            sequenceName = "cards_sequence", allocationSize = 1
    )
    @GeneratedValue(
            strategy = GenerationType.SEQUENCE,
            generator = "cards_sequence"
    )
    @Column(name = "c_id")
    private @Getter @Setter BigInteger c_id;
    @Column(name = "credit_card_number")
    private @Getter @Setter String credit_card_number ;
    @Column(name = "expiry_date")
    private @Getter @Setter String expiry_date;
    @Column(name = "name_on_card")
    private @Getter @Setter String name_on_card;

}
