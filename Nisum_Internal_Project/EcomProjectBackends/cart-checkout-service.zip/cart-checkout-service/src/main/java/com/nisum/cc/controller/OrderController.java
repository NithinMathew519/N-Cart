package com.nisum.cc.controller;

import com.nisum.cc.entity.Order;
import com.nisum.cc.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * OrderController contains controller methods for Placing an Order and get Order By Id.
 *
 * @author Harish, Harshitha
 */
@RequestMapping("/order")
@CrossOrigin(originPatterns = "http://localhost:4200")
@RestController
public class OrderController {

    @Autowired
    OrderService orderService;

    /**
     * Returns an Order after respective to oder id passes, if not present it will throw
     * RuntimeException.
     *
     * @param orderId
     * @return Order
     */
    @GetMapping(value = "/{orderId}", produces = "application/json")
    public Order getOrderById(@PathVariable int orderId) {
        return orderService.findByOrderId(orderId);
    }

    /**
     * Place an Order for given order body passed and store it on table, If duplicate order id is
     * present it will throw RuntimeException.
     * @param order
     * @return Order
     */
    @PostMapping(consumes = "application/json")
    public Order insertOrder(@RequestBody Order order) {
        return orderService.saveOrder(order);
    }

    /**
     * Executes when an RuntimeException is thrown, it returns a bad request status code and thrown exception
     * message in body.
     *
     * @param ex
     * @return String wrapped in ResponseEntity
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<String> handleOrderController(RuntimeException ex) {
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
    }

}
