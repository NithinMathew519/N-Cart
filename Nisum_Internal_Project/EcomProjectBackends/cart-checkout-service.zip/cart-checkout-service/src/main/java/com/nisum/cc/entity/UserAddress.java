package com.nisum.cc.entity;


import javax.persistence.*;

@Table(name = "user_address")
@Entity
public class UserAddress {

    @OneToOne
    @JoinColumn(name = "address_id", nullable = false,referencedColumnName = "addressId")
    private Address address;
    @Id
    @Column(name = "user_address_id")
    private long userAddressId;
    @Column(name = "email")
    private String email;


    public UserAddress(){}
    public long getUserAddressId() {
        return userAddressId;
    }

    public void setUserAddressId(long userAddressId) {
        this.userAddressId = userAddressId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public UserAddress(long userAddressId, String email, Address address) {
        this.userAddressId = userAddressId;
        this.email = email;
        this.address = address;
    }
}
