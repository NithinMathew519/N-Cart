package com.nisum.cc.service;


import com.nisum.cc.entity.Address;
import com.nisum.cc.repository.AddressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * Supporter class for controller class for adding address.
 * @author schowdhury
 */
@Service
public class AddressService {
    @Autowired
    AddressRepository addressRepository;

    public Address insertAddress(Address address){
        if (addressRepository.existsById(address.getAddressId())){
            throw new RuntimeException("Duplicate address ID");
        }
        return addressRepository.save(address);
    }

}
