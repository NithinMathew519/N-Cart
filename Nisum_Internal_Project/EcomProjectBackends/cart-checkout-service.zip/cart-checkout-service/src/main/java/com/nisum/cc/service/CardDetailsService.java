package com.nisum.cc.service;

import com.nisum.cc.entity.CardDetails;
import com.nisum.cc.repository.CardDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CardDetailsService {
    @Autowired
    private CardDetailsRepository cardDetailsRepository;

    public CardDetails saveCardDetails(CardDetails cardDetails) {
         return cardDetailsRepository.save(cardDetails);
    }
    public List<CardDetails> getCardDetails() {
        List<CardDetails> allCardDetails = cardDetailsRepository.findAll();

        List<CardDetails> maskedCardDetails = allCardDetails.stream().map(cardDetails -> {
            cardDetails.setCredit_card_number(cardDetails.getCredit_card_number().replaceAll("\\d(?=(?:\\D*\\d){4})", "X"));
            return cardDetails;
        }).collect(Collectors.toList());
        return maskedCardDetails;
    }
}
