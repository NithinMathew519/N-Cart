package com.nisum.cc.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.nisum.cc.entity.Cart;

public interface CartRepository extends JpaRepository<Cart,Integer> {
	
	public List<Cart> findAllByEmail(String email);

}
