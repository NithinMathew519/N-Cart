package com.nisum.cc.service;

import com.nisum.cc.entity.Cart;
import com.nisum.cc.repository.CartRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * It refers the services for the controllers and autowired the ItemService also.
 * @author hmuppala
 */
@Service
public class CartService {
	
	@Autowired
	CartRepository cartRepository;
	
	@Autowired
    ItemService productService;

	/**
	 * Returns the list of items present in the cart.
	 * @param email By email ,we are getting the items of one specific user.
	 * @return it will return the List of cart items.
	 */
	public List<Cart> getAllCartItems(String email){
		List<Cart> cartList=cartRepository.findAllByEmail(email);
		return cartList;
		
	}

	/**
	 * Get the Cart items by giving ID
	 * @param cartId by giving cartId it needs to check weather it is existing or not
	 * @return get the cart items
	 */
	public Cart getCartById(int cartId){
		if(!cartRepository.existsById(cartId)){
			throw new RuntimeException("cartId is Not Found");
		}
		 Optional<Cart> cart= cartRepository.findById(cartId);
       return cart.get();
	}

	/**
	 * To Add the new item int the cart
	 * @param cart By cart object ,to add the item in the cart
	 * @return returning the save cart in repository
	 */
	public Cart addItemToCart(Cart cart){
		  List<Cart> cartList = getAllCartItems(cart.getEmail()).stream()
				 .filter(cartItem -> cartItem.getItem().getItemId()==cart.getItem().getItemId())
				 .collect(Collectors.toList());
			if(cartList.size()>0)
			{
				Cart newCart = cartList.get(0);
				newCart.setQuantity(newCart.getQuantity()+1);
				return  cartRepository.save(newCart);
			}
		return cartRepository.save(cart);
	}

	/**
	 * If the cart is empty,delete the items in the cart
	 * @param Ids pass the list of cart Id's
	 * @return if the all items are deleted will give response true.
	 */
	public boolean deleteAllCartItems(List<Integer> Ids){
		Ids.stream().map(id->{
				if(!cartRepository.existsById(id)){
					throw new RuntimeException("ID is not found");
				}
					return null;
				}
		);
		cartRepository.deleteAllById(Ids);
		return true;
	}

	/**
	 * To remove the item present in the cart.
	 * First it needs to check the count after deleting the cartID.
	 * Then,count should be decreased.
	 * @param cartId Based on Cart Id only it will delete the specific cart
	 * @return if the cart is deleted will return true response.
	 */
	public boolean deleteByCartId( int cartId){
		long count = cartRepository.count();
		cartRepository.deleteById(cartId);
		if(count>cartRepository.count())
		{
			return true;
		}
		return false;

	}

	/**
	 * If the user wants to increase the quantity of item.
	 * then based on cartId (i.e.,items are already present in the cart)
	 * only that item should be incremented.
	 * @param cartId tells the which cart should be updated.
	 * @param quantity using patch mapping it will update the specific field.
	 * @return item present in the cart
	 */
	public Cart updateQuantityByCartId(int cartId,int quantity){
		Optional<Cart> cart= cartRepository.findById(cartId);
		if(cart.isPresent()){
			Cart c = cart.get();
			System.out.println(c.getCartId());
			c.setQuantity(quantity);
			return cartRepository.save(c);
		}
       throw new RuntimeException("CartID is not found");
	}

}

