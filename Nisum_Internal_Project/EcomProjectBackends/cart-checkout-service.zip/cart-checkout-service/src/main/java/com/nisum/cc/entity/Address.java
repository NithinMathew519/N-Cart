package com.nisum.cc.entity;

import lombok.*;

import javax.persistence.*;

/**
 * Entity class
 * @author schowdhury
 */
@Entity
@Table(name = "address_book")
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class Address {
    @Id
    @SequenceGenerator(
            name="address_sequence",
            sequenceName="address_sequence",allocationSize = 1,
            initialValue = 101)
    @GeneratedValue(
            strategy =GenerationType.SEQUENCE,
            generator = "address_sequence"
    )
    private @Getter @Setter long addressId;
    @Column(name = "full_name")
    private @Getter @Setter String full_name;
    @Column(name = "MobileNumber")
    private @Getter @Setter long mobile_number;
    @Column(name = "Address")
    private @Getter @Setter String address;
    @Column(name = "State")
    private @Getter @Setter String state;
    @Column(name = "City")
    private @Getter @Setter String city;
    @Column(name = "Pincode")
    private @Getter @Setter int pincode;


}
