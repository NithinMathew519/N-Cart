package com.nisum.cc.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "items")
public class Item {


	@Id
	@Column(name = "item_id")
	private int itemId;

	@Column(name = "category_id")
	private int categoryId;

	@Column(name = "sub_category_id")
	private int subCategoryId;

	@Column(name = "item_name")
	private String itemName;

	@Column(name = "item_brand")
	private String itemBrand;

	@Column(name = "item_desc")
	private String itemDesc;

	@Column(name = "item_price")
	private int itemPrice;

	@Column(name = "item_image")
	private String itemImage;

	public Item() {

		// TODO Auto-generated constructor stub
	}

	public Item(int itemId, int categoryId, int subCategoryId, String itemName, String itemBrand, String itemDesc,
			int itemPrice, String itemImage) {
		super();
		this.itemId = itemId;
		this.categoryId = categoryId;
		this.subCategoryId = subCategoryId;
		this.itemName = itemName;
		this.itemBrand = itemBrand;
		this.itemDesc = itemDesc;
		this.itemPrice = itemPrice;
		this.itemImage = itemImage;
	}

	public int getItemId() {
		return itemId;
	}

	public void setItemId(int itemId) {
		this.itemId = itemId;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSubCategoryId() {
		return subCategoryId;
	}

	public void setSubCategoryId(int subCategoryId) {
		this.subCategoryId = subCategoryId;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getItemBrand() {

		return itemBrand;

	}

	public void setItemBrand(String itemBrand) {
		this.itemBrand = itemBrand;
	}

	public String getItemDesc() {
		return itemDesc;
	}

	public void setItemDesc(String itemDesc) {
		this.itemDesc = itemDesc;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getItemImage() {
		return itemImage;
	}

	public void setItemImage(String itemImage) {
		this.itemImage = itemImage;
	}

}
