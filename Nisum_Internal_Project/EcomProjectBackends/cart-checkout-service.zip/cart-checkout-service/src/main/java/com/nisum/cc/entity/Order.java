package com.nisum.cc.entity;

import java.sql.Timestamp;

import java.util.Date;
import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import org.hibernate.annotations.NotFound;
import org.hibernate.annotations.NotFoundAction;

@Entity
@Table(name="orders")
public class Order {

	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="order_id",referencedColumnName = "order_id")
	private List<OrderDetails> orderDetails;


	@Id
	@SequenceGenerator(
			name="order_sequence",
			sequenceName="order_sequence",allocationSize = 1,
			initialValue = 101)
	@GeneratedValue(
			strategy =GenerationType.AUTO,
			generator = "order_sequence"
	)
	@Column(name="order_id")
	private int orderId;
	
	@Column(name="email")
	private String email;
	
	@Column(name="c_id")
	private int cardId;
	
	@Column(name="address_id")
	private int addressId;
	
	@Column(name="order_date")
	private Timestamp orderDate;
	
	@Column(name="total_price")
	private float totalPrice;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Order(List<OrderDetails> orderDetails, int orderId, String email, int cardId, int addressId, Timestamp orderDate, float totalPrice) {
		this.orderDetails = orderDetails;
		this.orderId = orderId;
		this.email = email;
		this.cardId = cardId;
		this.addressId = addressId;
		this.orderDate = orderDate;
		this.totalPrice = totalPrice;
	}

	public List<OrderDetails> getOrderDetails() {
		return orderDetails;
	}

	public void setOrderDetails(List<OrderDetails> orderDetails) {
		this.orderDetails = orderDetails;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getCardId() {
		return cardId;
	}

	public void setCardId(int cardId) {
		this.cardId = cardId;
	}

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public Timestamp getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	public float getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(float totalPrice) {
		this.totalPrice = totalPrice;
	}
}
