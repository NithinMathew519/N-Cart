package com.nisum.cc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.nisum.cc.entity.Item;
import com.nisum.cc.service.ItemService;

@RequestMapping("/item")
@RestController
public class ItemController {

	      @Autowired
	      ItemService itemService;
	      
	      
	      @GetMapping(value="/{itemId}",produces="application/json")
	      public Item getitemById(@PathVariable int itemId)
	      {
	    	   return itemService.findByItemId(itemId);
	      }
}
