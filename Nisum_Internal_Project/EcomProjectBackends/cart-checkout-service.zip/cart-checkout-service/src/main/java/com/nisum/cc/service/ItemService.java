package com.nisum.cc.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nisum.cc.entity.Cart;
import com.nisum.cc.entity.Item;
import com.nisum.cc.repository.ItemRepository;

@Service
public class ItemService {
	
	@Autowired
	ItemRepository itemRepository;
	
public Item findByItemId(int productId) {
		
		System.out.println("Order Service");
		 Optional<Item> p = itemRepository.findByItemId(productId);
    	 if(p.isPresent()) return p.get();
    	 return new Item();
	}

}
