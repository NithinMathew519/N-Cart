package com.nisum.cc.service;

import com.nisum.cc.entity.UserCreditCard;
import com.nisum.cc.repository.UserCreditCardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserCreditCardService {
    @Autowired
    UserCreditCardRepository userCreditCardRepository;

    public List<UserCreditCard> getAllCreditCardByEmail(String email) {
        return userCreditCardRepository.findByEmail(email);
    }
}
