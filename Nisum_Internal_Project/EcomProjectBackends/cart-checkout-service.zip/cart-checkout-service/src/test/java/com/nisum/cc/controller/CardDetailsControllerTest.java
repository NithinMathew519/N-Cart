package com.nisum.cc.controller;

import com.nisum.cc.entity.CardDetails;
import com.nisum.cc.service.CardDetailsService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;


class CardDetailsControllerTest {

    @InjectMocks
    private CardDetailsController cardDetailsController;

    @Mock
    private CardDetailsService cardDetailsService;


    @BeforeEach
    void setUp() {
        cardDetailsController = new CardDetailsController();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("send card to database")
    void addCard() {
        CardDetails card1 = new CardDetails(120, "1234567891234561", "12/2022", "Lokesh");
        Mockito.when(cardDetailsService.saveCardDetails(card1)).thenReturn(card1);
        assertEquals(card1, cardDetailsController.addCardDetails(card1));
    }

    @Test
    @DisplayName("Adding a null address object")
    void addNullAddress(){
        CardDetails card1 = new CardDetails(1, "1234567891234567", "12/2022", "Lokesh");
        Mockito.when(cardDetailsService.saveCardDetails(card1)).thenThrow(RuntimeException.class);
        assertThrows(RuntimeException.class,()->cardDetailsController.addCardDetails(card1),"");
    }

}
