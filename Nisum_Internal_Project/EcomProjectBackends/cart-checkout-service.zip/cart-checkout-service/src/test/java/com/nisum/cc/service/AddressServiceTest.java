package com.nisum.cc.service;

import com.nisum.cc.entity.Address;
import com.nisum.cc.repository.AddressRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

class AddressServiceTest {
    @Mock
    AddressRepository addressRepository;

    @InjectMocks
    AddressService addressService;

    @BeforeEach
    void setUp() {
        addressService = new AddressService();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("sending duplicate addressID for failed test case")
    void testAddAddressSerivceGivenDuplicateIdExpectedRuntimeError(){
        Address address = new Address(1L,"Test",8329044559L,"add1234 add","Mahrashtra","Pune",411026);
        Mockito.when(addressRepository.existsById(1L)).thenReturn(true);
        assertThrows(RuntimeException.class,()->addressService.insertAddress(address),"Duplicate address ID");
    }

    @Test
    @DisplayName("sending address to service")
    void testAddAddressServiceGivenNewAddressExpectedAddress(){
        Address address = new Address(1L,"Test",8329044559L,"add1234 add","Mahrashtra","Pune",411026);
        Mockito.when(addressRepository.save(address)).thenReturn(address);
        assertEquals(address,addressService.insertAddress(address));
    }



}