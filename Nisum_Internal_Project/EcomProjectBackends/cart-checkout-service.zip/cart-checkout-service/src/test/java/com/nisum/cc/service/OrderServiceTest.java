package com.nisum.cc.service;

import com.nisum.cc.entity.Order;
import com.nisum.cc.entity.OrderDetails;
import com.nisum.cc.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.sql.Timestamp;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class OrderServiceTest {

    @InjectMocks
    private OrderService orderService;

    @Mock
    private OrderRepository orderRepository;


    @BeforeEach
    public void setUp() throws Exception {
        orderService = new OrderService();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Get Order by Id When order with given order id is present")
    public void testOrderByIdGivenByAllValidDataThenExpectValidOrder() {
        OrderDetails od1 = new OrderDetails(1, 2, 1001);
        OrderDetails od2 = new OrderDetails(2, 1, 10002);
        List<OrderDetails> orderDetailsList = Arrays.asList(od1, od2);
        Order orderExpected = new Order(orderDetailsList, 101, "harishk@gmail.com", 1, 2, new Timestamp(System.currentTimeMillis()), 2000);

        Mockito.when(orderRepository.findByOrderId(101)).thenReturn(Optional.of(orderExpected));

        assertEquals(orderExpected, orderService.findByOrderId(101));

    }

    @Test
    @DisplayName("Get Order by Id When order with given order id is not present")
    public void testOrderByIdGivenByInvalidDataThenExpectErrorMessage() {
        assertThrows(RuntimeException.class, () -> orderService.findByOrderId(102), "Order with given Order Id 102 not found.");

    }

    @Test
    @DisplayName("Place an order with valid Order Details")
    public void testPlacingOrderGivenByAllValidDataThenExpectValidOrder() {
        OrderDetails od1 = new OrderDetails(1, 4, 10004);
        OrderDetails od2 = new OrderDetails(2, 2, 10006);
        List<OrderDetails> orderDetailsList = Arrays.asList(od1, od2);
        Order orderExpected = new Order(orderDetailsList, 190, "ram@gmail.com", 4, 6, new Timestamp(System.currentTimeMillis()), 5000);

        Mockito.when(orderService.saveOrder(orderExpected)).thenReturn(orderExpected);

        assertEquals(orderExpected, orderService.saveOrder(orderExpected));
    }

    @Test
    @DisplayName("Placing an Order with duplicate Order Id")
    public void testPlacingOrderGivenByInvalidDataThenExpectErrorMessage() {
        OrderDetails od1 = new OrderDetails(3, 1, 10010);
        OrderDetails od2 = new OrderDetails(4, 4, 10012);
        List<OrderDetails> orderDetailsList = Arrays.asList(od1, od2);
        Order orderExpected = new Order(orderDetailsList, 190, "ram@gmail.com", 2, 3, new Timestamp(System.currentTimeMillis()), 12000);

        Mockito.when(orderRepository.existsById(190)).thenReturn(true);
        assertThrows(RuntimeException.class, () -> orderService.saveOrder(orderExpected), "Order with Order Id 190 is already exist.");
    }
}