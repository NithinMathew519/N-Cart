package com.nisum.cc.service;

import com.nisum.cc.entity.Cart;
import com.nisum.cc.entity.Item;
import com.nisum.cc.repository.CartRepository;
import org.junit.jupiter.api.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;


class CartServiceTest {

    @InjectMocks
    private CartService cartService;

    @Mock
    private CartRepository cartRepository;

    @BeforeEach
    void setUp(){
        cartService = new CartService();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("Get the values from Cart By CartId")
    void testGetCartByIdGivenAllValidDataThenExpectCart(){
        Item item=new Item(1,2,1,"122n","Dell","image",300,"162");
        Cart cart = new Cart(item,1,"aaa@gmail.com",6);
        Cart cartListExpectedValue = cart;

        Mockito.when(cartRepository.existsById(1)).thenReturn(true);
        Mockito.when(cartRepository.findById(1)).thenReturn(Optional.of(cart));
        Assertions.assertEquals(cartListExpectedValue,cartService.getCartById(1));

    }

    @Test
    @DisplayName("Get all the cart Items")
    void testCartByEmailGivenAllValidDataThenExpectListOfCart(){
        Cart cart = new Cart(new Item(),2,"bbb@gmail.com",5);
        Cart cart1 = new Cart(new Item(),3,"aaa@gmail.com",6);
        List<Cart> cartListExpectedValue = Arrays.asList(cart,cart1);

        Mockito.when(cartRepository.findAllByEmail("shs@gmail.com")).thenReturn(cartListExpectedValue);
        Assertions.assertEquals(cartListExpectedValue,cartService.getAllCartItems("shs@gmail.com"));
    }

    @Test
    @DisplayName("Add items into the cart")
    void testAddItemToCartGivenAllValidDataThenExpectValidCart(){
        Cart cart = new Cart(new Item(),4,"ccc@gmail.com",1);
        Cart cartListExpectedValue = cart;
        Mockito.when(cartRepository.save(cart)).thenReturn(cartListExpectedValue);
        Assertions.assertEquals(cartListExpectedValue,cartService.addItemToCart(cart));
    }

    @Test
    @DisplayName("To delete the all cart items")
    void testDeleteByCartIdGivenValidDataThenExpectedValidTrue(){
        Cart cart4 = new Cart(new Item(),4,"ccc@gmail.com",1);
        Mockito.when(cartRepository.count()).thenReturn(10l).thenReturn(9l);
        Assertions.assertEquals(true,cartService.deleteByCartId(4));

    }

    @Test
    @DisplayName("To delete the all cart items")
    void testDeleteAllCartItemsGivenAllValidDataThenExpectedValidTrue(){
        Cart cart4 = new Cart(new Item(), 5, "aaa@gmail.com", 1);
        Cart cart5 = new Cart(new Item(), 6, "rrr@gmail.com", 5);
        List<Integer> cartListExpectedValue = Arrays.asList(1, 2);

//        Mockito.when(cartRepository.deleteAllById(cartListExpectedValue)).thenReturn(true);
        Assertions.assertEquals(true,cartService.deleteAllCartItems(cartListExpectedValue));

    }

    @Test
    @DisplayName("Update the cart and quantity")
    void testUpdateAndQuantityOfCartGivenAllValidDataThenExpectedValidCart(){

        Cart cart6 = new Cart(new Item(), 6, "bb@gmail.com", 7);
        Cart cartListExpectedValue = cart6;

        Mockito.when(cartRepository.findById(6)).thenReturn(Optional.of(cartListExpectedValue));
        Mockito.when(cartRepository.save(cartListExpectedValue)).thenReturn((cartListExpectedValue));
        Assertions.assertEquals(cartListExpectedValue,cartService.updateQuantityByCartId(6,5));


    }



}