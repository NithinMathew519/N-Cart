package com.nisum.cc.controller;

import com.nisum.cc.entity.Address;
import com.nisum.cc.repository.AddressRepository;
import com.nisum.cc.service.AddressService;
import org.junit.jupiter.api.Assumptions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

class AddressControllerTest {
    @InjectMocks
    private AddressController addressController;
    @Mock
    private AddressService addressService;

    @Mock
    private AddressRepository addressRepository;

    @BeforeEach
    void setUp() {
        addressController = new AddressController();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("send address to database")
    void testaddAddress(){
        Address address = new Address(1,"Test",8329044559L,"add123","Maharashtra","Pune",411026);
        Mockito.when(addressService.insertAddress(address)).thenReturn(address);
        assertEquals(address,addressController.addAddress(address));
    }

    @Test
    @DisplayName("Adding a null address object")
    void addNullAddress(){
        Address add1 = new Address(1,"Test",8329044559L,"add123","Maharashtra","Pune",411026);
        Mockito.when(addressService.insertAddress(add1)).thenThrow(RuntimeException.class);
        assertThrows(RuntimeException.class,()->addressController.addAddress(add1),"");
    }


}