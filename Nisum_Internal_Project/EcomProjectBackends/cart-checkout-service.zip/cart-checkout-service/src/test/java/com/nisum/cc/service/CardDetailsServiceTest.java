package com.nisum.cc.service;

import com.nisum.cc.entity.CardDetails;
import com.nisum.cc.repository.CardDetailsRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;

class CardDetailsServiceTest {

    @Mock
    CardDetailsRepository cardDetailsRepository;

    @InjectMocks
    CardDetailsService cardDetailsService;

    @BeforeEach
    void setUp() {
        cardDetailsService = new CardDetailsService();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("sending duplicate addressID for failed test case")
    void testCardDetailsGivenDuplicateIdExpectedRuntimeError(){
        CardDetails cardDetails = new CardDetails(1, "1234567891234567", "12/2022","Lokesh" );
        Mockito.when(cardDetailsRepository.existsById(1)).thenReturn(true);
        assertThrows(RuntimeException.class,()->cardDetailsService.saveCardDetails(cardDetails),"Duplicate card ID");
    }

    @Test
    @DisplayName("sending address to service")
    void testCardDetailsServiceGivenNewCardDEtailsExpectedCard(){
        CardDetails cardDetails = new CardDetails(1, "1234567891234567", "12/2022","Lokesh");
        Mockito.when(cardDetailsRepository.save(cardDetails)).thenReturn(cardDetails);
        assertEquals(cardDetails,cardDetailsService.saveCardDetails(cardDetails));
    }



}