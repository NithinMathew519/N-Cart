package com.nisum.cc;

import com.nisum.cc.controller.CartController;
import com.nisum.cc.entity.Cart;
import com.nisum.cc.entity.Item;
import com.nisum.cc.service.CartService;
import org.junit.jupiter.api.*;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;


import java.util.Arrays;
import java.util.List;

import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.is;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;


//@RunWith(MockitoJUnitRunner.class)
public class CartControllerTests {
    @InjectMocks
    private CartController cartController;
    @Mock
    private CartService cartService;

    @BeforeEach
    void setUp() {
        cartController = new CartController();
        MockitoAnnotations.openMocks(this);
    }

    @Test
    @DisplayName("get All Cart Items")
    void testCartByEmailGivenAllValidDataThenExpectListOfCart() {
        Cart cart1 = new Cart(new Item(), 1, "shs@gmail.com", 1);
        Cart cart2 = new Cart(new Item(), 1, "hhh@gmail.com", 1);
        List<Cart> cartListExpectedValue = Arrays.asList(cart1, cart2);

        String testEmailId = "abc@gmail.com";
        Mockito.when(cartService.getAllCartItems(testEmailId)).thenReturn(cartListExpectedValue);


        Assumptions.assumeFalse(testEmailId.isEmpty());
        Assertions.assertEquals(cartListExpectedValue, cartController.getAllCartItems(testEmailId));

        testEmailId = "";
        Assumptions.assumeTrue(testEmailId.isEmpty());
        Assertions.assertThrows(RuntimeException.class, () -> cartController.getAllCartItems(""));
    }

    @Test
    @DisplayName("Add Item into the cart")
    void testAddItemToCartGivenAllValidDataThenExpectValidCart() {
        Cart cart3 = new Cart(new Item(), 1, "shs@gmail.com", 1);
        Cart cartListExpectedValue = (cart3);

        Mockito.when(cartService.addItemToCart(cart3)).thenReturn(cartListExpectedValue);
        Assertions.assertEquals(cartListExpectedValue, cartController.addItemToCart(cartListExpectedValue));

        cartListExpectedValue=null;
        Assumptions.assumeTrue(cartListExpectedValue==null);
        Assertions.assertThrows(RuntimeException.class, () ->cartController.addItemToCart(null));

    }

    @Test
    @DisplayName("Deleting the cart Items")
    void testDeleteAllCartItemsGivenAllValidDataThenExpectedValidTrue() {
        Cart cart4 = new Cart(new Item(), 5, "aaa@gmail.com", 1);
        Cart cart5 = new Cart(new Item(), 6, "rrr@gmail.com", 5);
        List<Integer> cartListExpectedValue = Arrays.asList(1, 2);
        List<Integer> cartListExpectedValue1 = Arrays.asList();

        Mockito.when(cartService.deleteAllCartItems(cartListExpectedValue)).thenReturn(true);
        Assertions.assertEquals(true, cartController.deleteAllCartItems(cartListExpectedValue));

        Assumptions.assumeTrue(cartListExpectedValue1.isEmpty());
        Assertions.assertThrows(RuntimeException.class, () -> cartController.deleteAllCartItems(cartListExpectedValue1));

    }

    @Test
    @DisplayName("Update the quantity of the cart")
    void testUpdateAndQuantityOfCartGivenAllValidDataThenExpectedValidCart() {
        Cart cart6 = new Cart(new Item(), 6, "bb@gmail.com", 7);
        Cart cartListExpectedValue = (cart6);

        Mockito.when(cartService.updateQuantityByCartId(6, 7)).thenReturn(cartListExpectedValue);
        Assertions.assertEquals(cartListExpectedValue, cartController.updateQuantityOfCart(6, 7));
    }

    @Test
    @DisplayName("Delete the Items based on ID")
    void testDeleteByCartIdGivenValidDataThenExpectedValidTrue() {
        Cart cart7 = new Cart(new Item(), 7, "raj@gmail.com", 1);

        Mockito.when(cartService.deleteByCartId(7)).thenReturn(true);
        Assertions.assertEquals(true, cartController.deleteAllCartById(7));

        int cartId=0;
        Assertions.assertThrows(RuntimeException.class, () -> cartController.deleteAllCartById(0));

    }


}
